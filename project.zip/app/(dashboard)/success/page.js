
export default function Dashboardpage() {
  return (
    <div>
        <h1>Payment Successful!</h1>
        <p>Thank you for your payment.</p>
    </div> 
  )
}
